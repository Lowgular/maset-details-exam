export interface CityModel {
  readonly id: number;
  readonly breed: string;
}
