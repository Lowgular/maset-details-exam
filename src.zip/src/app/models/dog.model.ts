export interface DogModel {
  readonly id: number;
  readonly cityId: number;
  readonly breed: string;
}
