import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CityModel } from '../models/city.model';

@Injectable({ providedIn: 'root' })
export class CityService {
  constructor(private _httpClient: HttpClient) {}

  getAllCity(): Observable<CityModel[]> {
    return this._httpClient.get<CityModel[]>(
      'https://636ce2d8ab4814f2b2712854.mockapi.io/same-city-dogs'
    );
  }
}
